#!/bin/bash

cd $SVF_HOME

bash setup.sh
bash setup.sh debug

