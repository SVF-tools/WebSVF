mv ~/WORKSPACE/SVF ~/project/

cd ~/project/

cd SVF
mkdir Release-build
cd Release-build
cmake ../
make -j4


