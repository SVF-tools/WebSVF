###############################################################################
###############################################################################
##                             AUTO INSTALL SVF                              ##
##                                                                           ##
## Hi, guys.                                                                 ##
##                                                                           ##
## Please make sure you manchine has 4cores and 5GB ram at least.            ##
##                                                                           ##
## Make sure your linux system is ubuntu 16.04 or 18.04 +                    ##
## Make sure user has root authority. it means root or sudo user.            ##
##                                                                           ##
## If you are not a root user, make sure your system has been installed sudo.##
##                                                                           ##
## Each time you should use 'source AutoInstallSVF' to run.                  ##
## Each time you should use 'source AutoInstallSVF' to run.                  ##
## Each time you should use 'source AutoInstallSVF' to run.                  ##
## The important things maust said three times :)                            ##
## Please do not use other way. That is Essential!                           ##
##                                                                           ##
## Do not warry about the PATH env                                           ##
## This script  can handle itself no mater how many times you use it         ##
##                                                                           ##
## However, the program will clean old results before new mission.           ##
## So, make sure you take the important data out of there.                   ##
##                                                                           ##
## After you have installed the SVF.                                         ##
## There are some tools you might be intertsted to take for youself.         ##
## All of them in subset folder.                                             ##
##                                                                           ##
## You can use check_network.sh to check network connection.                 ##
## Or you may like edit show_example-test.sh to build you own tools.         ##
##                                                                           ##
## OK, That is all. I Hope you like it.                                      ##
## Tianyang.Guan                                                             ##
## 22/Mar/2019 Fri 4:10AM                                                    ##
##                                                                           ##
###############################################################################
###############################################################################
